import { CONFIG } from "./config.js";
import {
  getStatus,
  getLatestVideos,
  getPatreonPosts,
  getYoutubeChannels,
  vodsOf,
  isConfigured
} from "./lib/api.js";

// ---------- Formatage ----------
function pad(n) { return String(n).padStart(2, "0"); }

function uptime(iso) {
  const diff = Math.max(0, Date.now() - new Date(iso).getTime());
  const h = Math.floor(diff / 3600000);
  const m = Math.floor((diff % 3600000) / 60000);
  return h > 0 ? `${h}h${pad(m)}` : `${m}min`;
}

function fmtVodDuration(d) {
  if (!d) return "";
  const h = /(\d+)h/.exec(d);
  const m = /(\d+)m/.exec(d);
  const s = /(\d+)s/.exec(d);
  if (h) return `${h[1]}h${pad(m ? m[1] : 0)}min`;
  if (m) return `${m[1]}min${pad(s ? s[1] : 0)}`;
  return d;
}

function relative(iso) {
  const diff = Date.now() - new Date(iso).getTime();
  const day = 86400000;
  if (diff < 3600000) return "il y a " + Math.floor(diff / 60000) + " min";
  if (diff < day) return "il y a " + Math.floor(diff / 3600000) + " h";
  const days = Math.floor(diff / day);
  if (days === 1) return "hier";
  if (days < 7) return "il y a " + days + " jours";
  if (days < 30) return "il y a " + Math.floor(days / 7) + " sem.";
  return "il y a " + Math.floor(days / 30) + " mois";
}

function fmtNumber(n) {
  if (n >= 1000000) return (n / 1000000).toFixed(1).replace(".0", "") + "M";
  if (n >= 1000) return (n / 1000).toFixed(1).replace(".0", "") + "k";
  return String(n);
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])
  );
}

// ---------- Icones reseaux (fill=currentColor -> couleur pilotee par la DA) ----------
const SOCIAL_SVG = {
  twitch: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M2.149 0L.537 4.119v16.836h5.731V24h3.224l3.045-3.045h4.657L23.463 15V0H2.149zm19.164 14.045l-3.582 3.582h-5.731l-3.045 3.045v-3.045H4.687V1.79h16.626v12.255zm-3.582-7.373v5.731h-2.149V6.672h2.149zm-5.731 0v5.731H9.851V6.672h2.149z"/></svg>',
  youtube: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>',
  patreon: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M14.82 2.41c3.96 0 7.18 3.24 7.18 7.21 0 3.96-3.22 7.18-7.18 7.18-3.97 0-7.21-3.22-7.21-7.18 0-3.97 3.24-7.21 7.21-7.21M2 21.6h3.5V2.41H2V21.6z"/></svg>',
  discord: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M20.317 4.369a19.79 19.79 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.211.375-.444.865-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.369a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.1 13.1 0 0 1-1.872-.892.077.077 0 0 1-.008-.128c.126-.094.252-.192.372-.291a.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.009c.12.099.246.198.373.292a.077.077 0 0 1-.006.127 12.3 12.3 0 0 1-1.873.891.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.84 19.84 0 0 0 6.002-3.03.077.077 0 0 0 .032-.056c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028zM8.02 15.331c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/></svg>'
};

// ---------- Chaines YouTube (nom + photo de profil), memorise pour la session ----------
let channelsPromise = null;
function youtubeChannels(bust) {
  if (!channelsPromise || bust) {
    channelsPromise = getYoutubeChannels(bust).catch(() => []);
  }
  return channelsPromise;
}
function channelInfo(list, key) {
  const cfg = CONFIG.youtube.find((c) => c.key === key) || {};
  const api = (list || []).find((c) => c.key === key) || {};
  return {
    key,
    title: api.title || cfg.name || cfg.handle || "",
    handle: api.handle || cfg.handle || "",
    url: api.url || cfg.url || "#",
    avatar: api.avatar || null
  };
}

// ---------- Live / VOD ----------
const VOD_LABEL = { archive: "Live", highlight: "Temps fort" };

function vodCard(v) {
  const label = VOD_LABEL[v.type] || "Live";
  return `
    <div class="stream-card">
      <a class="thumb-wrap" href="${v.url}" target="_blank">
        ${v.thumbnail ? `<img src="${v.thumbnail}" alt="">` : ""}
        <span class="badge-type">${label}</span>
        <span class="badge-time">⏱ ${fmtVodDuration(v.duration)}</span>
      </a>
      <div class="card-body">
        <div class="card-title">${escapeHtml(v.title)}</div>
        <div class="meta-row">
          <span class="chip">📅 <b>${relative(v.date)}</b></span>
          <span class="chip">👁 <b>${fmtNumber(v.views)}</b> vues</span>
        </div>
        <a class="watch-btn" href="${v.url}" target="_blank">Regarder</a>
      </div>
    </div>`;
}

function vodItem(v) {
  const label = VOD_LABEL[v.type] || "Live";
  return `
    <a class="video-item" href="${v.url}" target="_blank">
      <div class="vi-thumb">
        ${v.thumbnail ? `<img src="${v.thumbnail}" alt="">` : ""}
        <span class="vi-dur">${fmtVodDuration(v.duration)}</span>
      </div>
      <div class="video-meta">
        <strong>${escapeHtml(v.title)}</strong>
        <span><b class="tag">${label}</b> ${relative(v.date)} • ${fmtNumber(v.views)} vues</span>
      </div>
    </a>`;
}

async function renderLive(bust) {
  const el = document.getElementById("liveContent");
  const pill = document.getElementById("statusPill");
  try {
    const d = await getStatus(bust);
    if (d.live && d.stream) {
      const s = d.stream;
      pill.innerHTML = '<span class="dot"></span>EN LIVE';
      pill.className = "pill live";
      el.innerHTML = `
        <div class="stream-card">
          <a class="thumb-wrap" href="https://twitch.tv/${CONFIG.twitchLogin}" target="_blank">
            ${s.thumbnail ? `<img src="${s.thumbnail}?_=${Date.now()}" alt="">` : ""}
            <span class="badge-live"><span class="dot"></span>LIVE</span>
            <span class="badge-time">⏱ ${uptime(s.startedAt)}</span>
          </a>
          <div class="card-body">
            <div class="card-title">${escapeHtml(s.title || "")}</div>
            <div class="meta-row">
              <span class="chip mint">👁 <b>${fmtNumber(s.viewers)}</b> viewers</span>
              ${s.game ? `<span class="chip">🎮 ${escapeHtml(s.game)}</span>` : ""}
            </div>
            <a class="watch-btn" href="https://twitch.tv/${CONFIG.twitchLogin}" target="_blank">Regarder le live</a>
          </div>
        </div>`;
    } else {
      pill.textContent = "HORS LIGNE";
      pill.className = "pill off";
      const vods = vodsOf(d).slice(0, 3);
      if (!vods.length) {
        el.innerHTML = `<div class="empty">Aucun live ni temps fort disponible.</div>`;
      } else {
        el.innerHTML = `
          <div class="section-label">Derniers lives &amp; temps forts</div>
          ${vodCard(vods[0])}
          ${vods.length > 1 ? `<div class="vod-list">${vods.slice(1).map(vodItem).join("")}</div>` : ""}`;
      }
    }
  } catch (e) {
    el.innerHTML = `<div class="error">Erreur : ${escapeHtml(e.message)}</div>`;
  }
}

// ---------- Planning (iframe) ----------
function renderPlanning() {
  const wrap = document.getElementById("planningWrap");
  if (wrap.dataset.loaded) return;
  wrap.dataset.loaded = "1";
  wrap.innerHTML = `<iframe src="${CONFIG.planningUrl}" loading="lazy" referrerpolicy="no-referrer"
    sandbox="allow-scripts allow-same-origin allow-popups allow-forms allow-popups-to-escape-sandbox"></iframe>`;
}

// ---------- Patreon (3 dernieres publications) ----------
const PATREON_SVG = '<svg viewBox="0 0 24 24" fill="#fff"><path d="M14.82 2.41c3.96 0 7.18 3.24 7.18 7.21 0 3.96-3.22 7.18-7.18 7.18-3.97 0-7.21-3.22-7.21-7.18 0-3.97 3.24-7.21 7.21-7.21M2 21.6h3.5V2.41H2V21.6z"/></svg>';
async function renderPatreon(bust) {
  const el = document.getElementById("patreonContent");
  try {
    const data = await getPatreonPosts(bust);
    if (data.configured === false) {
      el.innerHTML =
        data.reason === "auth"
          ? `<div class="empty">🔑 Authentification Patreon expirée.<br>
             Le renouvellement automatique n'a pas pu aboutir :<br>
             vérifie <b>PATREON_REFRESH_TOKEN</b>, <b>PATREON_CLIENT_ID</b><br>
             et <b>PATREON_CLIENT_SECRET</b> sur Vercel<br>(voir server/README.md).</div>`
          : `<div class="empty">Onglet Patreon à activer :<br>
             ajoute la variable <b>PATREON_ACCESS_TOKEN</b> sur Vercel<br>(voir server/README.md).</div>`;
      return;
    }
    const posts = data.posts || [];
    if (!posts.length) {
      el.innerHTML = `<div class="empty">Aucune publication Patreon.</div>`;
      return;
    }
    el.innerHTML = posts.map((p) => `
      <a class="video-item" href="${p.url || "#"}" target="_blank">
        ${p.thumbnail
          ? `<img src="${p.thumbnail}" alt="">`
          : `<div class="patreon-thumb">${PATREON_SVG}</div>`}
        <div class="video-meta">
          <strong>${escapeHtml(p.title)}</strong>
          <span>${p.date ? relative(p.date) : ""}${p.isPublic ? "" : " • réservé"}</span>
        </div>
      </a>`).join("");
  } catch (e) {
    el.innerHTML = `<div class="error">Erreur : ${escapeHtml(e.message)}</div>`;
  }
}

// ---------- Videos (une section par chaine YouTube) ----------
const YT_MINI_SVG = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>';

function videosSection(info, vids, err) {
  const head = `
    <div class="chan-head">
      <span class="chan-id">
        ${info.avatar
          ? `<img class="chan-avatar" src="${info.avatar}" alt="">`
          : `<span class="chan-avatar fallback">${YT_MINI_SVG}</span>`}
        <b>${escapeHtml(info.title)}</b>
      </span>
      <a href="${info.url}" target="_blank">Voir la chaîne ↗</a>
    </div>`;
  let body;
  if (err) body = `<div class="error">Erreur : ${escapeHtml(err)}</div>`;
  else if (!vids.length) body = `<div class="empty small">Aucune vidéo trouvée.</div>`;
  else
    body = vids.map((v) => `
      <a class="video-item" href="${v.url}" target="_blank">
        ${v.thumbnail ? `<img src="${v.thumbnail}" alt="">` : ""}
        <div class="video-meta">
          <strong>${escapeHtml(v.title)}</strong>
          <span>${relative(v.date)}</span>
        </div>
      </a>`).join("");
  return `<div class="chan-block">${head}${body}</div>`;
}

async function renderVideos(bust) {
  const el = document.getElementById("videosContent");
  const [list, ...results] = await Promise.all([
    youtubeChannels(bust),
    ...CONFIG.youtube.map((c) =>
      getLatestVideos(3, bust, c.key).then(
        (vids) => ({ vids }),
        (e) => ({ vids: [], err: e.message })
      )
    )
  ]);
  el.innerHTML = CONFIG.youtube
    .map((c, i) => videosSection(channelInfo(list, c.key), results[i].vids, results[i].err))
    .join("");
}

// ---------- Reseaux (icone seule, sur tous les onglets) ----------
function renderSocials() {
  const el = document.getElementById("socials");
  el.innerHTML = CONFIG.socials.map((s, i) => `
    <a class="social ${s.icon}" data-i="${i}" href="${s.url}" target="_blank"
       title="${escapeHtml(s.name)}" aria-label="${escapeHtml(s.name)}">
      ${SOCIAL_SVG[s.icon] || ""}
    </a>`).join("");
  // Remplace les icones YouTube par la vraie photo de profil des chaines (async).
  youtubeChannels().then((list) => {
    CONFIG.socials.forEach((s, i) => {
      if (!s.ytKey) return;
      const info = channelInfo(list, s.ytKey);
      if (!info.avatar) return;
      const a = el.querySelector(`.social[data-i="${i}"]`);
      if (!a) return;
      a.classList.add("avatar-social");
      a.title = info.title || s.name;
      a.setAttribute("aria-label", info.title || s.name);
      a.innerHTML = `<img src="${info.avatar}" alt="">`;
    });
  });
}

// ---------- Notifications toggle ----------
function initNotifToggle() {
  const btn = document.getElementById("notifToggle");
  const state = document.getElementById("notifState");
  async function refresh() {
    const d = await chrome.storage.local.get("notificationsEnabled");
    const on = d.notificationsEnabled !== false;
    state.textContent = on ? "ON" : "OFF";
    btn.classList.toggle("off", !on);
  }
  btn.addEventListener("click", async () => {
    const d = await chrome.storage.local.get("notificationsEnabled");
    const on = d.notificationsEnabled !== false;
    await chrome.storage.local.set({ notificationsEnabled: !on });
    refresh();
  });
  refresh();
}

// ---------- Onglets ----------
const loaded = {};
function initTabs() {
  document.querySelectorAll(".tab").forEach((tab) => {
    tab.addEventListener("click", () => {
      document.querySelectorAll(".tab").forEach((t) => t.classList.remove("active"));
      document.querySelectorAll(".panel").forEach((p) => p.classList.remove("active"));
      tab.classList.add("active");
      const name = tab.dataset.tab;
      document.getElementById("tab-" + name).classList.add("active");
      lazyLoad(name);
    });
  });
}
function lazyLoad(name) {
  if (loaded[name]) return;
  loaded[name] = true;
  if (name === "planning") renderPlanning();
  if (name === "videos") renderVideos();
  if (name === "patreon") renderPatreon();
}

// ---------- Init ----------
document.getElementById("planningOpen").href = CONFIG.planningUrl;
const patreonSocial = CONFIG.socials.find((s) => s.icon === "patreon");
document.getElementById("patreonOpen").href = patreonSocial ? patreonSocial.url : "#";

// ---------- Bouton Actualiser (force le rechargement, sans cache) ----------
function initRefresh() {
  const btn = document.getElementById("refreshBtn");
  let busy = false;
  btn.addEventListener("click", async () => {
    if (busy || !isConfigured()) return;
    busy = true;
    btn.classList.add("spin");
    const activeTab = document.querySelector(".tab.active");
    const active = activeTab ? activeTab.dataset.tab : "live";
    try {
      await renderLive(true); // met a jour la pastille de statut + l'onglet Live
      if (active === "videos") await renderVideos(true);
      else if (active === "patreon") await renderPatreon(true);
      else if (active === "planning") {
        const w = document.getElementById("planningWrap");
        w.dataset.loaded = ""; w.innerHTML = "";
        renderPlanning();
      }
      chrome.runtime.sendMessage({ type: "poll-now" }).catch(() => {});
    } finally {
      setTimeout(() => { btn.classList.remove("spin"); busy = false; }, 500);
    }
  });
}

(function init() {
  renderSocials();
  initTabs();
  initNotifToggle();
  initRefresh();

  if (!isConfigured()) {
    document.getElementById("liveContent").innerHTML =
      `<div class="empty">⚙️ Le proxy n'est pas encore configuré.<br>
       Renseigne <b>proxyBase</b> dans <code>config.js</code> après avoir déployé le dossier <b>/server</b>.</div>`;
    return;
  }

  loaded.live = true;
  renderLive();
  chrome.runtime.sendMessage({ type: "poll-now" }).catch(() => {});
})();
